//
//  XMGKVONotifying_Person.h
//  02-响应式编程思想
//
//  Created by yz on 15/9/23.
//  Copyright © 2015年 yz. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Person.h"

@interface XMGKVONotifying_Person : Person

@end
