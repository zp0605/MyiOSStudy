//
//  Account.h
//  ReactiveCocoa
//
//  Created by yz on 15/10/5.
//  Copyright © 2015年 yz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Account : NSObject

@property (nonatomic, strong) NSString *account;

@property (nonatomic, strong) NSString *pwd;

@end
