//
//  User.m
//  07-Runtime(字典转模型)(了解)
//
//  Created by xiaomage on 15/10/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "User.h"

@implementation User

@end
