//
//  NSObject+Objc.h
//  04-Runtime(分类添加属性)
//
//  Created by xiaomage on 15/10/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSObject (Objc)

@property (nonatomic, strong) NSString *name;

@end
