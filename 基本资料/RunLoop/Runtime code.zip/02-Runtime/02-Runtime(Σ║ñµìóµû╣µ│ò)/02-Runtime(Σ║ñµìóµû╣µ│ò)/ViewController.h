//
//  ViewController.h
//  02-Runtime(交换方法)
//
//  Created by xiaomage on 15/10/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

