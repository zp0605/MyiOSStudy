//
//  zs.h
//  day10
//
//  Created by xiaomage on 15/6/15.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

// 为了放置重复导入, 一般情况下会在.h中添加上 头文件卫士

//#ifndef __ZS__H__ // 判断是否"没有"定义了名称叫做 __ZS__H__ 的宏
//#define __ZS__H__ // 定义一个叫做__ZS__H__的宏

// 加法运算
// v1 , v2需要参与运算的数据
int sum(int v1, int v2);
#include "ls.h"
//#endif