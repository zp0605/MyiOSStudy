//
//  abc.c
//  Test
//
//  Created by xiaomage on 15/6/15.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include "abc.h"

int num;
void test()
{
    
}