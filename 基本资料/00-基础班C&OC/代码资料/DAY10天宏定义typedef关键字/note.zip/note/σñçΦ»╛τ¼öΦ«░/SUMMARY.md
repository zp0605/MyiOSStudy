# Summary

* [全局变量和局部变量](README.md)
* [static和extern关键字-对变量的作用](8.md)
* [static和extern关键字-对函数的作用](staticextern1-/README.md)
* [预处理指令基本概念](2.md)
* [宏定义](3.md)
* [条件编译基本概念](5.md)
* [typedef关键字](typedef/README.md)
* [宏定义与函数以typedef区别](4.md)
* [const关键字](const/README.md)
* [总结](8.md)
* [作业](9/README.md)

