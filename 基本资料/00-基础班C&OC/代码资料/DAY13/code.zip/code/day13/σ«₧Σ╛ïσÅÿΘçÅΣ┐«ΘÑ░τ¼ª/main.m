//
//  main.m
//  实例变量修饰符
//
//  Created by xiaomage on 15/6/19.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Student.h"

int main(int argc, const char * argv[]) {
    
    Person *p = [Person new];
//    p->_age = 30;
//    p->_height = 1.75;
//    p->_weight = 60.0;
//    p->_name = @"lnj";
    
    Student *stu = [Student new];
    NSLog(@"-----");
    return 0;
}
