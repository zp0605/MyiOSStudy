//
//  Animal.m
//  day13
//
//  Created by xiaomage on 15/6/19.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Animal.h"

@implementation Animal
- (void)eat
{
    NSLog(@"吃东西");
}
@end
