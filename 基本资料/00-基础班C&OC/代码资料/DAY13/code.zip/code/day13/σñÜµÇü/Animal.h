//
//  Animal.h
//  day13
//
//  Created by xiaomage on 15/6/19.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Animal : NSObject
{
    int _age;
}

- (void)eat;
@end
