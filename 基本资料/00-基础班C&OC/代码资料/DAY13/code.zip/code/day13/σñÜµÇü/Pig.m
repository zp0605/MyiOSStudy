//
//  Pig.m
//  day13
//
//  Created by xiaomage on 15/6/19.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Pig.h"

@implementation Pig

- (void)eat
{
    NSLog(@"大口吃");
}
@end
