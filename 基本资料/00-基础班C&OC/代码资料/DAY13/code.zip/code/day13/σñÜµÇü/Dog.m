//
//  Dog.m
//  day13
//
//  Created by xiaomage on 15/6/19.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Dog.h"

@implementation Dog


- (void)eat
{
    NSLog(@"啃骨头");
}

- (void)kanJia
{
    NSLog(@"看家, 旺旺叫");
}
@end
