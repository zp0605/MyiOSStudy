//
//  main.c
//  while练习3
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    // 帅哥要和靓女搭讪, 想搞定这个靓女的陌陌号码
    // 靓女的要求, 要求男生猜她的年龄, 给这个男生3次机会
    
    // 1.男生猜多少? 用户输入
    // 2.女生的真实年龄? 随机数
    // 3.根据用户的输入, 判断是否和女生的真实年龄一样
    
    /*
    // 1.让男生猜
    printf("请猜猜我得年龄\n");
    int age = -1;
    scanf("%i", &age);
    */
    // 2.确定女生的年龄
    int girl = arc4random_uniform(20);
    /*
    // 3.判断是否猜对了
    if (age == girl) {
        printf("陌陌号码是: shijijiayuan");
    }else if (age > girl)
    {
        printf("你会不会说话, 我有那么老吗?\n");
    }else if (age < girl)
    {
        printf("我太开心了``你真会聊天\n");
    }
     */
    int count = 3;
    while (count > 0) {
        // 1.让男生猜
        printf("请猜猜我得年龄\n");
        int age = -1;
        scanf("%i", &age);
        
        // 3.判断是否猜对了
        if (age == girl) {
            printf("陌陌号码是: shijijiayuan\n");
            system("say shijijiayuan");
            break; // break可以用在switch和循环结构中
            // 只要执行到break那么就不会再次回去判断条件了
        }else if (age > girl)
        {
            printf("你会不会说话, 我有那么老吗?\n");
            system("say 你会不会说话, 我有那么老吗?");
        }else if (age < girl)
        {
            printf("我太开心了``你真会聊天\n");
            system("say 我太开心了``你真会聊天");
        }
        count--; // 减少他得机会
    }
    
    return 0;
}
