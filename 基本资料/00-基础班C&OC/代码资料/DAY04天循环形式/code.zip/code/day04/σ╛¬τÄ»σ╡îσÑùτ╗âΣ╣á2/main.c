//
//  main.c
//  循环嵌套练习2
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    /*
     
     ***
     **
     *
     
     */
    // 只要以后看到很多行很多列, 那么第一时间就要想到循环嵌套
    // 定义一个变量保存当前需要输出的星星的个数
    /*
    int couon = 3;
    for (int i = 0; i < 3; i++) {
//        printf("count = %i", couon);
        for (int j = 0; j < couon; j++) {
            printf("*");
        }
        printf("\n");
        couon--; // 每输出一行就让列数减一
    }
     */
    /*
    int count = 0;
    for (int i = 0; i < 3; i++) {
        printf("i = %i", i);
//        printf("count = %i", count);
        for (int j = count; j < 3; j++) {
            printf("*");
        }
        printf("\n");
        count++;
    }
     */
    /*
//    int count = 0;
    for (int i = 0; i < 3; i++) {
//        printf("i = %i", i);
        for (int j = i; j < 3; j++) {
            printf("*");
        }
        printf("\n");
//        count++;
    }
     */
    
    
    /*
     
     *
     **
     ***
     
     */
    /*
    int count = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j <= count; j++) {
            printf("*");
        }
        printf("\n");
        count++;
    }
     */
    
//    int count = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j <= i; j++) {
            printf("*");
        }
        printf("\n");
//        count++;
    }
    
    /*
     尖尖朝上: 修改内循环的 条件表达式
     尖尖朝下: 修改内循环的 初始化表达式
     */
    
    return 0;
}
