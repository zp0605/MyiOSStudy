//
//  main.c
//  循环嵌套练习1
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    /*
     ***
     ***
     ***
     */
//    printf("***\n");
    /*
    printf("*");
    printf("*");
    printf("*\n");
     */
    /*
    printf("*");
    printf("*");
    printf("*");
    printf("\n");
     */
    /*
    for (int i = 0; i < 3; i++) {
        printf("*");
    }
    printf("\n");
    
    for (int i = 0; i < 3; i++) {
        printf("*");
    }
    printf("\n");
    
    for (int i = 0; i < 3; i++) {
        printf("*");
    }
    printf("\n");
     */
    // 外循环控制行数
    // 内循环控制列数
    for (int j = 0 ; j < 2; j++) {
        for (int i = 0; i < 3; i++) {
            printf("*");
        }
        printf("\n");
    }
    
    return 0;
}
