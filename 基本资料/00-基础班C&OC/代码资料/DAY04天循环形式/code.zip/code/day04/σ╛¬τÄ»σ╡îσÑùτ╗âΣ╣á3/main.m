//
//  main.m
//  循环嵌套练习3
//
//  Created by 李南江 on 15/6/20.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    /*
     1
     12
     123
     */
    /*
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j <= i; j++) {
            printf("%i", j + 1);
        }
        printf("\n");
    }
     */
    
    /*
     1
     22
     333
     */
    /*
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%i", i + 1);
        }
        printf("\n");
    }
     */
    
    /*
     --*
     -***
     *****
     
     --
     -
     
      *
     ***
    *****
     */
    for (int i = 0; i < 3; i++) {
        for (int j = i; j < 2; j++) {
            printf("-");
        }
        
        //                   0 * 2 = 0
        //                   1 * 2 = 2
        //                   2 * 2 = 4
        for (int n = 0; n <= i * 2; n++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
