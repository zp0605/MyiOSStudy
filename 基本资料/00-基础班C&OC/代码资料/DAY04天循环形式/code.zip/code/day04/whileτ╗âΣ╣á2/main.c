//
//  main.c
//  while练习2
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    // 获取1～100之间 7的倍数的个数并打印，并统计个数
    // 1.分析
    
    // 1.获取0~100之间所有的数
    // 2.判断当前拿到的数是否是7的倍数, 没有余数
    // 3.定义变量保存7的倍数的个数(每次只要发现当前的数是7的倍数就加1)
    
    // 修改变量名称的快捷键 command + control + e
    int number = 0;
    int count = 0;
    while (number <= 20) {
        printf("%i\n", number);
        if (number % 7 == 0) {
            // 证明当前的数是7的倍数
            count++;// 计数器思想, 如果以后开发中项获取什么中有多少个什么, 第一个时间就要想到计数器思想
            printf("7的倍数是 %i\n", number);
        }
        number++;
    }
    printf("sum = %i\n", count);
    return 0;
}

void call()
{
    int count = 0;
}
