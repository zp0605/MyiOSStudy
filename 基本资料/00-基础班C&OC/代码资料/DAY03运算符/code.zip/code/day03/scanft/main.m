//
//  main.m
//  scanft
//
//  Created by xiaomage on 15/7/22.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
        // 江哥提示:insert code here...
        NSLog(@"Hello, World!");
    return 0;
}
