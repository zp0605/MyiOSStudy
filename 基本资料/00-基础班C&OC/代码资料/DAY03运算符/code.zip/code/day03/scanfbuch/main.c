//
//  main.c
//  scanfbuch
//
//  Created by xiaomage on 15/7/22.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
   
//    定义两个字符类型的变量,并依次单个输入输出!

//    1.定义两个变量
    char a;
    int b;
//    2.提示用户输入
    printf("亲,来两个字符!\n");
//    3.接收用户输入
    scanf("%c",&a);
//    4.输出
    printf("a = %c\n",a);
//    getchar();
//    char c;
//    scanf("%c",&c);
    scanf("%i",&b);
    printf("b = %i\n",b);
    
//    4.输出

    
    
    return 0;
}
