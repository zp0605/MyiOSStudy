//
//  AppDelegate.h
//  石头剪子布
//
//  Created by 李南江 on 14-2-18.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
