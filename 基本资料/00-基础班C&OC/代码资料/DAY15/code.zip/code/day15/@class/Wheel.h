//
//  Wheel.h
//  day15
//
//  Created by xiaomage on 15/6/24.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Wheel : NSObject

@property (nonatomic, assign) int size;
@end
