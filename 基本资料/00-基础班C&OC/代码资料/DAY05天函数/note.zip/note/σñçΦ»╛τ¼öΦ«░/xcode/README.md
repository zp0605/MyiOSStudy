# Xcode运行原理
##本小节知识点:
1. 【了解】Xcode运行原理
2. 【了解】常见的UNIX命令

---

##1.Xcode运行原理
- 当我们点击运行后xcode自动帮我们做如下事情:
    + 编译--->.o(目标文件)--->链接--->.out 执行
![](http://7xj0kx.com1.z0.glb.clouddn.com/yuandaimafenxi.png)
---

##2.常见的UNIX命令
- Mac系统采用的是UNIX文件系统,所有的文件都放在根目录/下面,因此没有Windows中分C盘、D盘 的概念
- 因为Mac系统是基于UNIX系统的,因此可以在“终端”中输入一些UNIX指令来操作Mac系统 常用的UNIX指令:(需要经常使用才不容易忘记)
```
ls :列出当前目录下的所有内容(文件\文件夹) pwd :显示出当前目录的名称
cd :改变当前操作的目录
who :显示当前用户名
clear :清除所有内容
mkdir : 创建一个新目录
rm: 删除文件
rm -r: 删除文件夹 -f 强制删除
touch: 创建文件
vi /open:打开、创建文件
    -q 退出
    -wq 保存并退出
    -q!强制退出
    i 进入编辑模式
    esc 退出编辑模式
    :wq!
cat/more 都可以查看文件内容
```
