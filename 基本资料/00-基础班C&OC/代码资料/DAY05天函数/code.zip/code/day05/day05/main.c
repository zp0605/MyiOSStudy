//
//  main.c
//  day05
//
//  Created by xiaomage on 15/6/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>
/*
 打飞机的功能:
 左移, 右移, 上移, 下移 , 开炮 , 死
 
 将人类的思维 --> 代码
 1. C语言程序是由函数组成
 2. 什么是函数? 函数就是一段具备特定功能的程序段
 */

// 向左移的函数
int left()
{
    printf("看反光镜\n");
    printf("向左打方向盘\n");
    printf("加油门\n");
    printf("回正方向盘\n");
    printf("通知后方的飞机\n");
    
    return 0;
}

// 向右移的函数
// 函数是一段具备特定功能的程序段
// 定义函数的目的: 将一个功能封装以来方便复用
int right()
{
    printf("看反光镜\n");
    printf("向右打方向盘\n");
    printf("加油门\n");
    printf("回正方向盘\n");
    return 0;
}

int main() {
    /*
     不使用函数的弊端:
     1.重复代码太多, 又臭又长
     2.当需求变更, 很多地方都需要修改代码
     */
    /*
     使用函数的好处:
     1.提高了代码的复用性, 代码更简洁
     2.当需求变更, 不用修改很多地方
     */
    
    left();
    printf("------\n");
    /*
    printf("看反光镜\n");
    printf("向左打方向盘\n");
    printf("加油门\n");
    printf("回正方向盘\n");
    printf("通知后方的飞机\n");
     */
    /*
    printf("看反光镜\n");
    printf("向右打方向盘\n");
    printf("加油门\n");
    printf("回正方向盘\n");
     */
    right();
    printf("------\n");
    /*
    printf("看反光镜\n");
    printf("向左打方向盘\n");
    printf("加油门\n");
    printf("回正方向盘\n");
    printf("通知后方的飞机\n");
     */
    left();

    
    
    return 0;
}
