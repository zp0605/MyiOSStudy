//
//  Person+NJ.m
//  day16
//
//  Created by xiaomage on 15/6/26.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Person+NJ.h"

@implementation Person (NJ)
// 实现扩充方法

- (void)playFootball
{
    NSLog(@"%s", __func__);
}

- (void)playBasketball
{
    NSLog(@"%s", __func__);
}
@end
