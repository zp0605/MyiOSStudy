//
//  Person.m
//  day16
//
//  Created by xiaomage on 15/6/26.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Person.h"
#import "NSString+NJ.h"

@implementation Person


-(void)test{
   NSString *str=@"fds64jkl43fjdslkf";
    int count =[NSString countWithStr:str];
    NSLog(@" count= %i",count);


}



@end
