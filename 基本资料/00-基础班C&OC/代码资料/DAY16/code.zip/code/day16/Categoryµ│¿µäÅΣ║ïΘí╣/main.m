//
//  main.m
//  Category注意事项
//
//  Created by xiaomage on 15/6/26.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person+NJ.h"

int main(int argc, const char * argv[]) {

    Person *p = [Person new];
//    p.height = 1.75;
    [p say];
    
    return 0;
}
