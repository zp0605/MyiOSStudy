//
//  Dog.h
//  day16
//
//  Created by xiaomage on 15/6/26.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Bone;

@interface Dog : NSObject

@property(nonatomic, strong)Bone *bone;

@end
