//
//  zs.h
//  day11
//
//  Created by xiaomage on 15/6/16.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#ifndef __day11__zs__
#define __day11__zs__

#include <stdio.h>
int sum(int v1, int v2);

#endif /* defined(__day11__zs__) */
