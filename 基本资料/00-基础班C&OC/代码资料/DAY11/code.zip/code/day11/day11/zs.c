//
//  zs.c
//  day11
//
//  Created by xiaomage on 15/6/16.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include "zs.h"

int sum(int v1, int v2)
{
    return v1 + v2;
}