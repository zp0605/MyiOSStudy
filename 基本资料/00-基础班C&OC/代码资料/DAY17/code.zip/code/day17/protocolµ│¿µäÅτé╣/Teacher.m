//
//  Teacher.m
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Teacher.h"

@implementation Teacher

- (void)playBasketball
{
    
}

- (void)playBaseball
{
    
}
- (void)playFootball
{
    
}

-(void)jumping
{
    
}
@end
