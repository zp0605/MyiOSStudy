//
//  Sutdent.m
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Sutdent.h"

@implementation Sutdent

- (void)playBasketball
{
    NSLog(@"%s", __func__);
}
@end
