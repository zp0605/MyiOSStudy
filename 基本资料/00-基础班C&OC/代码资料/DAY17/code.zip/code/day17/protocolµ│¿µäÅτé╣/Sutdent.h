//
//  Sutdent.h
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Person.h"

// 2.父类遵守了某个协议, 那么子类也会自动遵守这个协议
@interface Sutdent : Person

@end
