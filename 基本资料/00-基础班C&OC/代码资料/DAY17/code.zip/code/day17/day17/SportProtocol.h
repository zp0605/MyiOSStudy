//
//  SportProtocol.h
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SportProtocol <NSObject>
// 方法声明列表
- (void)playFootball;
- (void)playBasketball;
- (void)playBaseball;
@end
