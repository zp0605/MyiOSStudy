//
//  Person.h
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SportProtocol.h"

@interface Person : NSObject <SportProtocol>
//- (void)playFootball;
@end
