//
//  Student.m
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Student.h"

@implementation Student
- (void)playFootball
{
    NSLog(@"%s", __func__);
}

- (void)playBasketball
{
    NSLog(@"%s", __func__);
}

- (void)playBaseball
{
    NSLog(@"%s", __func__);
}
@end
