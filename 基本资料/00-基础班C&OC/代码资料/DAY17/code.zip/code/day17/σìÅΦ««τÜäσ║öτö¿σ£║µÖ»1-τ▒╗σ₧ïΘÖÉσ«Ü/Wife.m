//
//  Wife.m
//  day17
//
//  Created by xiaomage on 15/6/28.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


#import "Wife.h"

@implementation Wife
// 会做饭
- (void)cooking
{
    NSLog(@"%s", __func__);
}
// 会洗衣服
- (void)washing
{
    NSLog(@"%s", __func__);
}
// 有一份好工作
- (void)job
{
    NSLog(@"%s", __func__);
}
@end
