//
//  GoodStudent.h
//  day14
//
//  Created by xiaomage on 15/6/23.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Student.h"

@interface GoodStudent : Student

@end
