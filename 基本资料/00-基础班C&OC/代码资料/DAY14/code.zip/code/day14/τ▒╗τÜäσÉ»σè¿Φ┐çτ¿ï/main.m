//
//  main.m
//  类的启动过程
//
//  Created by xiaomage on 15/6/23.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "GoodStudent.h"

int main(int argc, const char * argv[]) {

//    Person *p1 = [[Person alloc] init];
//    Person *p2 = [[Person alloc] init];
//    Person *p3 = [[Person alloc] init];
//    Person *p4 = [[Person alloc] init];
    GoodStudent *gstu = [[GoodStudent alloc] init];
    return 0;
}
