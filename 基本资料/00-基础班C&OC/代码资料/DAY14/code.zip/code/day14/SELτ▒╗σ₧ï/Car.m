//
//  Car.m
//  day14
//
//  Created by 李南江 on 15/6/20.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "Car.h"

@implementation Car

- (void)run
{
    NSLog(@"run");
}
@end
