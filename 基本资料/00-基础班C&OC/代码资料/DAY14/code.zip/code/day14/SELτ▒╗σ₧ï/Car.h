//
//  Car.h
//  day14
//
//  Created by 李南江 on 15/6/20.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject
NSProxy

- (void)run;
@end
