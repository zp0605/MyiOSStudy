//
//  AppDelegate.h
//  18-copy内存管理
//
//  Created by 520it on 15/8/7.
//  Copyright (c) 2015年 520it. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

