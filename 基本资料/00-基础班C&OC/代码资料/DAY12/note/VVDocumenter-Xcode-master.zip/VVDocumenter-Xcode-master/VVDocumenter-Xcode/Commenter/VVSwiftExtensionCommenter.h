//
//  VVSwiftExtensionCommenter.h
//  VVDocumenter-Xcode
//
//  Created by WANG WEI on 2015/06/17.
//  Copyright (c) 2015年 OneV's Den. All rights reserved.
//

#import "VVBaseCommenter.h"

@interface VVSwiftExtensionCommenter : VVBaseCommenter

@end
