//
//  Iphone.m
//  day12
//
//  Created by xiaomage on 15/6/18.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Iphone.h"

@implementation Iphone

- (void)brand
{
    NSLog(@"苹果手机");
}

- (void)callWithNumber:(int)number
{
    NSLog(@"打电话给%i", number);
}
@end
