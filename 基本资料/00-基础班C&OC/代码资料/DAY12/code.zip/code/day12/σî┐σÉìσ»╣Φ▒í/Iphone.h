//
//  Iphone.h
//  day12
//
//  Created by xiaomage on 15/6/18.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Iphone : NSObject

// 打印当前手机品牌
- (void)brand;

- (void)callWithNumber:(int)number;
@end
