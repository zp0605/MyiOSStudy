//
//  main.m
//  修改项目模板
//
//  Created by xiaomage on 15/6/18.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

/*
 工程名称:
 文件名称:
 创建者  :
 创建时间:
 版权    :
 修改人  :
 修改时间:
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {

    /*
     修改项目模板以及main函数中的内容
     /Applications/Xcode.app/Contents/Developer/Library/Xcode/Templates/Project Templates/Mac/Application/Command Line Tool.xctemplate/
     
     修改OC文件头部的描述信息
     /Applications/Xcode.app/Contents/Developer/Library/Xcode/Templates/File Templates/Source/Cocoa Class.xctemplate
     
     */
    
    /*
     Xcode文档安装的位置1:
     /Applications/Xcode.app/Contents/Developer/Documentation/DocSets
     注意: 拷贝之前最好将默认的文档删除, 因为如果同时存在高版本和低版本的文档, 那么低版本的不会显示
     Xcode文档安装的位置2:
     /Users/你的用户名/Library/Developer/Shared/Documentation/DocSets
     如果没有该文件夹可以自己创建一个
     
     */
    // 江哥提示:insert code here...
    NSLog(@"Hello, World!");

    [NSString stringWithFormat:<#(NSString *), ...#>];

    return 0;
}
