//
//  Clip.m
//  day12
//
//  Created by xiaomage on 15/6/18.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Clip.h"

@implementation Clip

- (void)addBullet
{
    // 上子弹
    _bullet = 10;
}

@end