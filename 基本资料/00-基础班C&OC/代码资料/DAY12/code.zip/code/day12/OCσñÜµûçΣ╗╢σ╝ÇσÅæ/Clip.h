//
//  Clip.h
//  day12
//
//  Created by xiaomage on 15/6/18.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

@interface Clip : NSObject
{
@public
    int _bullet; // 子弹
}

/**
 *  上子弹
 */
- (void)addBullet;

@end
