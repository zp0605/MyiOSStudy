# iOS开发体验1
##本小节知识点:
1. 【了解】界面切换
![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_179.png)

---

##1.界面切换(无需代码)
- 拖拽一个导航界面到Main.Storyboard
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_158.png)

- 设置导航界面为启动后界面
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_163.png)

- 拖拽一个普通界面到Main.Storyboard
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_160.png)

- 设置普通界面为导航界面根界面
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_164.png)

- 拖拽一个按钮到普通界面
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_166.png)

- 再拖拽一个普通界面到Main.Storyboard
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_160.png)

- 从按钮拖拽一条线到第二个界面
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_167.png)

- 运行程序
    + ![](http://7xj0kx.com1.z0.glb.clouddn.com/Snip20150511_168.png)

---
