#include <stdio.h>

int main()
{
    // C语言中每一条语句后面都必须有;号
    // C语言中除了""引起来的地方, 其它任何地方都不能出现中文
    // main函数中的return 0;可以写, 也可以不写
    // main函数前面的int可以写, 可以不写
    // main函数后面的()不可以省略
    // 不要把main写错了
    // 同一程序中只能有一个main函数
    printf("lnj；");
    return 0;
}

/*
int main()
{
    return 0;
}
*/