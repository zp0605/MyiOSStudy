//
//  AppDelegate.h
//  iOS开发体验
//
//  Created by 李南江 on 15/6/1.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

