//
//  ViewController.m
//  06-CABaseAnimation
//
//  Created by Gavin on 15/9/16.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *redView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{

    //1.创建动画对象
    CABasicAnimation *anim = [CABasicAnimation animation];
    //2.核心动画的本质就是修改属性值.
//    anim.keyPath = @"transform.scale";
    anim.keyPath = @"position";
    //3.设置属性值
    anim.toValue = [NSValue valueWithCGPoint:CGPointMake(200, 400)];
    
    //4.动画完成时, 不要删除动画
    anim.removedOnCompletion = NO;
    //5.保存动画最前面效果
    anim.fillMode = kCAFillModeForwards;
    
    //添加动画
    [self.redView.layer addAnimation:anim forKey:nil];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
