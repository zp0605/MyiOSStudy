//
//  WheelsBtn.m
//  13-转盘
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "WheelsBtn.h"

@implementation WheelsBtn


//返回按钮当中的UIImageView的尺寸位置.
//contentRect:当前按钮的尺寸位置
-(CGRect)imageRectForContentRect:(CGRect)contentRect{

    CGFloat w = 40;
    CGFloat h = 50;
    CGFloat x= (contentRect.size.width - w) * 0.5;
    CGFloat y = 20;
    
    return CGRectMake(x, y, w, h);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
