//
//  ViewController.m
//  07-心跳
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}




-(void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    
    //创建动画对象
    CABasicAnimation *anim = [CABasicAnimation animation];
    //设置属性
    anim.keyPath = @"transform.scale";
    //设置属性值.
    anim.toValue = @0;
    
    //设置动画的执行次数
    anim.repeatCount = MAXFLOAT;
    
    //设置动画的执行时长
    anim.duration = 0.5;
    
    //自动反转
    anim.autoreverses = YES;
    
    //添加动画
    [self.imageV.layer addAnimation:anim forKey:nil];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
