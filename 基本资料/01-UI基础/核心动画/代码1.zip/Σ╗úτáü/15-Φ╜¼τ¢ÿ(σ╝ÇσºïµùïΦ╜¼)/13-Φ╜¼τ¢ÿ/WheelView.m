//
//  WheelView.m
//  13-转盘
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "WheelView.h"
#import "WheelsBtn.h"

@interface WheelView()


@property (weak, nonatomic) IBOutlet UIImageView *contentV;

@property(nonatomic,weak)UIButton *preBtn;

@property(nonatomic,strong) CADisplayLink *link;

@end


@implementation WheelView


-(CADisplayLink *)link{
    
    if (_link == nil) {
        
        CADisplayLink *link  = [CADisplayLink displayLinkWithTarget:self selector:@selector(update)];
        [link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
        _link = link;
        
    }
    return _link;

}

-(void)awakeFromNib{
    
    //添加按钮
    [self setUP];
}



//开始旋转
-(void)start{


    self.link.paused = NO;
    
}
- (void)update{
 
    //让转盘开始旋转
    self.contentV.transform = CGAffineTransformRotate(self.contentV.transform, M_PI / 200.0);

}


//暂停旋转
- (void)stop{

    self.link.paused = YES;

    
}
//开始选号
- (IBAction)startChoose:(id)sender {
    
    CABasicAnimation *anim = [CABasicAnimation animation];
    anim.keyPath = @"transform.rotation";
    anim.toValue = @(M_PI * 3);
    anim.duration = 1;

    [self.contentV.layer addAnimation:anim forKey:nil];
}



+(instancetype)wheelsView{

    return [[NSBundle mainBundle] loadNibNamed:@"WheelView" owner:nil options:nil][0];
}



- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self = [[NSBundle mainBundle] loadNibNamed:@"WheelView" owner:nil options:nil][0];
        //添加按钮
        [self setUP];
    }
    return self;
}

//添加按钮
- (void)setUP{
    
    
    self.contentV.userInteractionEnabled = YES;
    //创建按钮
    
    CGFloat btnW = 68;
    CGFloat btnH = 143;
    CGFloat angle = 0;
    
    //在C语言当中用的都是像素,我们这个地方加载@2x
    
    //加载原始图片
    UIImage *oriImage = [UIImage imageNamed:@"LuckyAstrology"];
    UIImage *oriSelImage = [UIImage imageNamed:@"LuckyAstrologyPressed"];
    
    
    //获取当前屏幕与像素坐标的比例
    CGFloat scale = [UIScreen mainScreen].scale;
    
    CGFloat clipW = oriImage.size.width / 12 * scale;
    CGFloat clipH = oriImage.size.height * scale;
    CGFloat clipX = 0;
    CGFloat clipY = 0;
    
    
    
    for(int i = 0; i < 12;i++){
    
        WheelsBtn *btn = [WheelsBtn buttonWithType:UIButtonTypeCustom];
        //设置按钮的尺寸
        btn.bounds = CGRectMake(0, 0, btnW, btnH);
        
        btn.layer.anchorPoint = CGPointMake(0.5, 1);
        btn.layer.position = CGPointMake(self.bounds.size.width * 0.5, self.bounds.size.height * 0.5);
        
//      btn.imageView.contentMode = UIViewContentModeCenter;
        
        
        //裁剪图片当中的某一块区域
        clipX = i * clipW;
        CGRect rect = CGRectMake(clipX, clipY, clipW, clipH);
        //裁剪正常状态下的图片
        CGImageRef clipImage = CGImageCreateWithImageInRect(oriImage.CGImage, rect);
        //裁剪选中状态下的图片.
        CGImageRef clipSelImage = CGImageCreateWithImageInRect(oriSelImage.CGImage, rect);
        

        //设置按钮的图片
        //把CGImageRef转成UIImage
        UIImage *clipNewImage = [UIImage imageWithCGImage:clipImage];
        [btn setImage:clipNewImage forState:UIControlStateNormal];
        
        //设置选中状态下的图片.
        UIImage *clipSelNewImage = [UIImage imageWithCGImage:clipSelImage];
        [btn setImage:clipSelNewImage forState:UIControlStateSelected];
        
  
        
        //设置选中的图片
        [btn setBackgroundImage:[UIImage imageNamed:@"LuckyRototeSelected"] forState:UIControlStateSelected];
        
        //监听按钮的点击
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        
    
        //添加按钮
        [self.contentV addSubview:btn];

        
        //让每个按钮进行旋转
        btn.transform = CGAffineTransformMakeRotation(angle / 180.0 * M_PI);
        angle += 30;
        
        //让第一个按钮成为选中状态.
        if(i == 0){
            [self btnClick:btn];
        }

    }
    

}


//当按钮点击的时候调用
- (void)btnClick:(UIButton *)btn{
    
    //让上一个选中按钮取消选中的状态
    self.preBtn.selected = NO;
    //让当前选中的按钮成为选中状态.
    btn.selected = YES;
    //把当前的按钮赋值给上一个按钮
    self.preBtn = btn;


}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
