//
//  ViewController.m
//  08-图片标动
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#define angle2Rad(angle) ((angle) / 180.0 * M_PI)

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *iconV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    
    
    //创建一个帧动画
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animation];
    
    //设置属性
    anim.keyPath = @"position";
    
//    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(50, 50, 300, 400)];
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(10, 50)];
    
    [path addLineToPoint:CGPointMake(300, 400)];
    
    
    anim.path = path.CGPath;

    
    //设置执行的次数
    anim.repeatCount = MAXFLOAT;
    
    anim.autoreverses = YES;
    
    anim.duration = 1;
    
    //添加动画
    [self.iconV.layer addAnimation:anim forKey:nil];
    
    
}


//图标抖动
- (void)values{

    //创建一个帧动画
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animation];
    
    //设置属性
    anim.keyPath = @"transform.rotation";
    
    //设置属性值.
    anim.values = @[@(angle2Rad(-5)),@(angle2Rad(5)),@(angle2Rad(-5))];
    //设置执行的次数
    anim.repeatCount = MAXFLOAT;
    
    anim.duration = 0.25;
    
    //添加动画
    [self.iconV.layer addAnimation:anim forKey:nil];

}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
