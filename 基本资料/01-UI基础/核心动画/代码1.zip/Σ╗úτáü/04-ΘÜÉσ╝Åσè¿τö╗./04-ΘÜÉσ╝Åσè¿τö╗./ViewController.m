//
//  ViewController.m
//  04-隐式动画.
//
//  Created by Gavin on 15/9/16.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(nonatomic,weak)CALayer *layer;
@property (weak, nonatomic) IBOutlet UIView *redView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    CALayer *layer = [CALayer layer];
    layer.bounds = CGRectMake(0, 0, 100, 100);
    layer.position = CGPointMake(100, 100);
    layer.backgroundColor = [UIColor greenColor].CGColor;
    self.layer = layer;
    [self.view.layer addSublayer:layer];
    

}



-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{

    //动画底层都是包装成一个事务.
    //有很多操作绑定在一起, 当这些操作全部执行完毕时,它才进行下一步工作.
    
    [CATransaction begin];
//
//    //设置事务有没有动画
    [CATransaction setDisableActions:NO];
    //设置事务动画的执行时长.
    [CATransaction setAnimationDuration:1];
    
    self.layer.bounds = CGRectMake(0, 0, arc4random_uniform(200), arc4random_uniform(200));
    self.layer.position = CGPointMake(arc4random_uniform(300), arc4random_uniform(400));
    self.layer.backgroundColor = [self randomColor].CGColor;
    self.layer.cornerRadius = arc4random_uniform(50);

    [CATransaction commit];
    

    
    
//    self.redView.layer.position = CGPointMake(200, 400);
    
    
    

}


- (UIColor *)randomColor{
    
    CGFloat r = arc4random_uniform(256) /255.0;
     CGFloat g = arc4random_uniform(256) /255.0;
     CGFloat b = arc4random_uniform(256) /255.0;
    
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
