//
//  ViewController.m
//  13-转盘
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "WheelView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    WheelView *wheels = [WheelView wheelsView];
    wheels.center = self.view.center;
    [self.view addSubview:wheels];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
