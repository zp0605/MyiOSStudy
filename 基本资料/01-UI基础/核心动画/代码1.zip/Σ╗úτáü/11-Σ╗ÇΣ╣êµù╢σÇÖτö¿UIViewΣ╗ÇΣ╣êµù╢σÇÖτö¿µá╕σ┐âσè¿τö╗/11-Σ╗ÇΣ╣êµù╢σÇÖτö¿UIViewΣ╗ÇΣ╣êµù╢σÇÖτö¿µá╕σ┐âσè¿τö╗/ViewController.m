//
//  ViewController.m
//  11-什么时候用UIView什么时候用核心动画
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    UIView动画与核心动画的区别?
    1.核心动画只作用在layer.
    2.核心动画修改的值都是假像.它的真实位置没有发生变化.
 
    什么时候用UIView动画什么时候用核心动画?
    当需要与用户进行交互时用UIView,不需要与用户进行交互时两个都可以.
 
    什么情况用核心动画最多?
    1.转场动画.
    2.帧动画.
    3.动画组.
 
 
 
 */



#import "ViewController.h"
#import "RedView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet RedView *redView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSLog(@"%@",NSStringFromCGRect(self.redView.frame));
    
}



-(void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{

    CABasicAnimation *anim = [CABasicAnimation animation];
    
    anim.keyPath = @"position.y";
    
    anim.toValue = @(400);
    
    anim.removedOnCompletion = NO;
    anim.fillMode = kCAFillModeForwards;
    
    [self.redView.layer addAnimation:anim forKey:nil];
    
    
    
    CABasicAnimation *scaleAnim = [CABasicAnimation animation];
    
    scaleAnim.keyPath = @"transform.scale";
    
    scaleAnim.toValue = @0.5;
    
    scaleAnim.removedOnCompletion = NO;
    scaleAnim.fillMode = kCAFillModeForwards;
    
    [self.redView.layer addAnimation:scaleAnim forKey:nil];
    
    
    
    
//    NSLog(@"--------%@",NSStringFromCGRect(self.redView.frame));
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
