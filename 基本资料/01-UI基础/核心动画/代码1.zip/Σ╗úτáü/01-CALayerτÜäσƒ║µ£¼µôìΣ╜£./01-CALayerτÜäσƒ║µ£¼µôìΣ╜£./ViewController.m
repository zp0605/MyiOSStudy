//
//  ViewController.m
//  01-CALayer的基本操作.
//
//  Created by Gavin on 15/9/16.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *redView;
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

   
    
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{

    [UIView animateWithDuration:1 animations:^{
        //3D
//        self.imageV.layer.transform = CATransform3DMakeRotation(M_PI, 1, 1, 0);
        
//        self.imageV.layer.transform = CATransform3DMakeTranslation(100, 50, 1);
        
//        self.imageV.layer.transform = CATransform3DMakeScale(0.5, 0.5, 0);
        
        //把结构体转成对象
        //做3d旋转的时候一般不用KVC
        //什么时候用KVC
        //做一些快速缩放,平移,二维旋转.
        NSValue *value = [NSValue valueWithCATransform3D:CATransform3DMakeRotation(M_PI, 1, 1, 0)];
        [self.imageV.layer setValue:@(M_PI) forKeyPath:@"transform.rotation.x"];
        
        
    }];
  
    
    
    
}


- (void)UIImageVLayer{
    //UIView本身就自带阴影效果,它是透明.
    self.imageV.layer.shadowOpacity = 1;
    //设置阴影的偏移量
    self.imageV.layer.shadowOffset = CGSizeMake(-30, -10);
    //设置阴影的模糊程度
    self.imageV.layer.shadowRadius = 10;
    //设置阴影的颜色
    self.imageV.layer.shadowColor = [UIColor blueColor].CGColor;
    
    
    
    //设置边框的颜色
    self.imageV.layer.borderColor = [UIColor greenColor].CGColor;
    //设置边框的宽度
    self.imageV.layer.borderWidth = 2;
    
    //设置圆角半径.
    self.imageV.layer.cornerRadius = 50;
    
    
    
    //我们设置的所有layer的属性只作用在根层上.
    NSLog(@"%@",self.imageV.layer.contents);
    //超过根层以外东西都会被裁剪掉.
    self.imageV.layer.masksToBounds = YES;
}


- (void)UIViewLayer{

    //UIView本身就自带阴影效果,它是透明.
    self.redView.layer.shadowOpacity = 1;
    //设置阴影的偏移量
    self.redView.layer.shadowOffset = CGSizeMake(-30, -10);
    //设置阴影的模糊程度
    self.redView.layer.shadowRadius = 10;
    //设置阴影的颜色
    self.redView.layer.shadowColor = [UIColor blueColor].CGColor;
    
    //设置边框的颜色
    self.redView.layer.borderColor = [UIColor greenColor].CGColor;
    //设置边框的宽度
    self.redView.layer.borderWidth = 2;
    
    //设置圆角半径.
    self.redView.layer.cornerRadius = 50;
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
