//
//  MuneItem.h
//  12-微博动画
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface MuneItem : NSObject

//图片
@property (nonatomic, strong) UIImage *image;
//标题
@property (nonatomic, strong) NSString *title;


+ (instancetype)itemWithTitle:(NSString *)title image:(UIImage *)image;


@end
