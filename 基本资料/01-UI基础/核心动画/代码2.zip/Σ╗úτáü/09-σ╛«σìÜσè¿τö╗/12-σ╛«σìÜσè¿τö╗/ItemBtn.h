//
//  ItemBtn.h
//  12-微博动画
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemBtn : UIButton

@end
