//
//  MuneItem.m
//  12-微博动画
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "MuneItem.h"

@implementation MuneItem




+ (instancetype)itemWithTitle:(NSString *)title image:(UIImage *)image{

    MuneItem *item = [[self alloc] init];
    item.title = title;
    item.image = image;
    
    return item;
}





@end
