//
//  ViewController.m
//  07-粒子效果
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "VCView.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet VCView *vcView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)start:(id)sender {
    
    [self.vcView start];
    
}
- (IBAction)reDraw:(id)sender {
    [self.vcView reDraw];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
