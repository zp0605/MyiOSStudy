//
//  ViewController.m
//  05-复制层
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *contentV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //复制层可以复制它里面子层
    //想要复制它里面的内容,也要把添加到个层上面.
    CAReplicatorLayer *repL = [CAReplicatorLayer layer];
    repL.frame = self.contentV.bounds;
    repL.backgroundColor = [UIColor redColor].CGColor;
    
    
    [self.contentV.layer addSublayer:repL];
    
    
    
    
    CALayer *layer = [CALayer layer];
    layer.frame = CGRectMake(10, 20, 30, 30);
    layer.backgroundColor = [UIColor greenColor].CGColor;
    [repL addSublayer:layer];
    
    
    
    
    CALayer *layer2 = [CALayer layer];
    layer2.frame = CGRectMake(10, 60, 30, 30);
    layer2.backgroundColor = [UIColor greenColor].CGColor;
    [repL addSublayer:layer2];
    
    
    
    
    //要复制的份.包括它自己.
    repL.instanceCount = 4;
    //相对复制出来的上一个子层做的平移.
    repL.instanceTransform = CATransform3DMakeTranslation(40, 0, 0);
    
    
    
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
