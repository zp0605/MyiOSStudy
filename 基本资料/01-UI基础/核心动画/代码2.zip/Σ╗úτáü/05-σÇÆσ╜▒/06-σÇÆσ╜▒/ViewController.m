//
//  ViewController.m
//  06-倒影
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.

    NSLog(@"%@",[self.view.layer class]);
    
    CAReplicatorLayer *repL =   (CAReplicatorLayer *)self.view.layer;
    repL.instanceCount = 2;
    //复制出来的子层,它都是绕着复制层锚点进行旋转.
    repL.instanceTransform = CATransform3DMakeRotation(M_PI, 1, 0, 0);
    
    repL.instanceRedOffset -= 0.1;
    repL.instanceGreenOffset -= 0.1;
    repL.instanceBlueOffset -= 0.1;
    repL.instanceAlphaOffset -= 0.1;

    
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
