//
//  ViewController.m
//  13-转盘
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "WheelView.h"

@interface ViewController ()

@property(nonatomic,weak)WheelView *wheels;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    WheelView *wheels = [WheelView wheelsView];
    wheels.center = self.view.center;
    self.wheels = wheels;
    [self.view addSubview:wheels];
    
    
}
//开始旋转
- (IBAction)start:(id)sender {
    
    [self.wheels start];
    
}

//暂停旋转
- (IBAction)stop:(id)sender {
    [self.wheels stop];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
