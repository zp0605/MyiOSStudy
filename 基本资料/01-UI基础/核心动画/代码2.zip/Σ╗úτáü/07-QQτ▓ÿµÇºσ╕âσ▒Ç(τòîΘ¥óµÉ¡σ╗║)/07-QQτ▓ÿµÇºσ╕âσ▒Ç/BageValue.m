//
//  BageValue.m
//  07-QQ粘性布局
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "BageValue.h"


@interface BageValue()

@property(nonatomic,weak) UIView *smallCircle;

@end

@implementation BageValue


-(void)awakeFromNib{
    [self setUP];
}


-(nonnull instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        [self setUP];
    }
    return self;
}

//初始化
- (void)setUP{
    
    //设置圆角
    self.layer.cornerRadius = 10;
    
    //设置文字大小
    self.titleLabel.font = [UIFont systemFontOfSize:12];
    
    //设置背景颜色.
    [self setBackgroundColor:[UIColor redColor]];
    
    
    //添加手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self addGestureRecognizer:pan];
    
    
    //添加小圆
    UIView *smallCircle = [[UIView alloc] init];
    smallCircle.frame = self.frame;
    smallCircle.layer.cornerRadius = self.layer.cornerRadius;
    smallCircle.backgroundColor  = self.backgroundColor;
    self.smallCircle = smallCircle;
    [self.superview insertSubview:smallCircle belowSubview:self];
    
    
    
}

//计算两个圆之间的距离
- (CGFloat)distanceWithSmallCircle:(UIView *)smallCircle bigCircle:(UIView *)bigCircle{
    
    CGFloat offsetX = bigCircle.center.x - smallCircle.center.x;
    CGFloat offsetY = bigCircle.center.y - smallCircle.center.y;
    
    return  sqrtf(offsetX * offsetX + offsetY * offsetY);
  
}





//当手指开始拖动的时候调用.
- (void)pan:(UIPanGestureRecognizer *)pan{

    //当前移动的偏移量
    CGPoint tranP = [pan translationInView:self];
    
    //frame,center,tansform
    //transform并没有修改center.它修改的frame.
//    self.transform = CGAffineTransformTranslate(self.transform, tranP.x, tranP.y);
    
    CGPoint center = self.center;
    center.x += tranP.x;
    center.y += tranP.y;
    self.center = center;
    //复位
    [pan setTranslation:CGPointZero inView:self];
    
    CGFloat distance = [self distanceWithSmallCircle:self.smallCircle bigCircle:self];
    
    //取出小圆的半径.
    CGFloat radius = self.bounds.size.width * 0.5;
    radius = radius - distance / 10.0;
    //重新设置小圆的宽高
    self.smallCircle.bounds = CGRectMake(0, 0, radius * 2, radius * 2);
    self.smallCircle.layer.cornerRadius = radius;
    
    
    NSLog(@"%f",distance);
    
    

}



-(void)setHighlighted:(BOOL)highlighted{

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
