//
//  BageValue.h
//  07-QQ粘性布局
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BageValue : UIButton

@end
