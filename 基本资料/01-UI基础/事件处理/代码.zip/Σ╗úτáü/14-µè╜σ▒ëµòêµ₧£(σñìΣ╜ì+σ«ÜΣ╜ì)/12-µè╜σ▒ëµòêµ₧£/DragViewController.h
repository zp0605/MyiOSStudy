//
//  DragViewController.h
//  12-抽屉效果
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DragViewController : UIViewController

@property (nonatomic, weak, readonly) UIView *leftV;
@property (nonatomic, weak, readonly) UIView *rightV;
@property (nonatomic, weak, readonly) UIView *mainV;

@end
