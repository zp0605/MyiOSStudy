//
//  DragViewController.m
//  12-抽屉效果
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "DragViewController.h"

#define screenW  [UIScreen mainScreen].bounds.size.width

@interface DragViewController ()



@end

@implementation DragViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加子控件
    [self setUpAllChildView];
    
    // 添加手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [_mainV addGestureRecognizer:pan];
    
    // 点按
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    
    [self.view addGestureRecognizer:tap];
}

- (void)tap
{
    // 点击控制器的view调用

    if (_mainV.frame.origin.x != 0) {
        [UIView animateWithDuration:0.25 animations:^{
            
            // 复位
            _mainV.frame = self.view.bounds;
        }];
    }
    
}

#define targetR 300
#define targetL -250


// 只要手指在mainV拖动的时候调用
- (void)pan:(UIPanGestureRecognizer *)pan
{
    // 让mainV随着手指移动而移动
    
    // 获取x轴偏移量
    CGFloat offsetX = [pan translationInView:_mainV].x;
    
    // 修改mainV的frame
    _mainV.frame = [self frameWithOffsetX:offsetX];
    
    // 复位
    [pan setTranslation:CGPointZero inView:_mainV];
    
    // 判断下当前显示左边的view,还是右边的view
    [self isShowLeftView];
    
    if (pan.state == UIGestureRecognizerStateEnded) {
        // 手指抬起,拖动结束
        // 定位功能
        NSLog(@"手指抬起");
        CGFloat target = 0;
        if (_mainV.frame.origin.x > screenW * 0.5) {
             // main.x > screenW * 0.5,定位到右边某个点
            target = targetR;
        }else if (CGRectGetMaxX(_mainV.frame) < screenW * 0.5){
            // max(main.x) < screenW * 0.5,定位到左边某个点
            target = targetL;
        }
        
        // 计算偏移量
        CGFloat offsetX = target - _mainV.frame.origin.x;
        
        [UIView animateWithDuration:0.25 animations:^{
            
            _mainV.frame = [self frameWithOffsetX:offsetX];
        }];

        
    }
}

// 判断下当前显示左边的view,还是右边的view
- (void)isShowLeftView
{
    if (_mainV.frame.origin.x > 0) { // 往右边,显示左边
        _rightV.hidden = YES;
    }else if (_mainV.frame.origin.x < 0){ // 往左边,显示右边
        _rightV.hidden = NO;
    }
}

#define maxY 100

// 计算当前mainV最新的frame
- (CGRect)frameWithOffsetX:(CGFloat)offsetX
{
    
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height;
    
    CGRect frame = _mainV.frame;
    
    // 最新的x
    CGFloat x = frame.origin.x += offsetX;
    
    CGFloat y = fabs(x / screenW * maxY);
    
    CGFloat h = screenH - 2 * y;
    
    CGFloat scale = h / screenH;
    
    CGFloat w = screenW * scale;
    
    
    return CGRectMake(x, y, w, h);
}

// 添加子控件
- (void)setUpAllChildView
{
    // left
    UIView *leftV = [[UIView alloc] initWithFrame:self.view.bounds];
    _leftV = leftV;
    leftV.backgroundColor = [UIColor greenColor];
    [self.view addSubview:leftV];
    
    // right
    UIView *rightV = [[UIView alloc] initWithFrame:self.view.bounds];
    _rightV = rightV;
    rightV.backgroundColor = [UIColor blueColor];
    [self.view addSubview:rightV];
    
    // main
    UIView *mainV = [[UIView alloc] initWithFrame:self.view.bounds];
    _mainV = mainV;
    mainV.backgroundColor = [UIColor redColor];
    [self.view addSubview:mainV];
}

@end
