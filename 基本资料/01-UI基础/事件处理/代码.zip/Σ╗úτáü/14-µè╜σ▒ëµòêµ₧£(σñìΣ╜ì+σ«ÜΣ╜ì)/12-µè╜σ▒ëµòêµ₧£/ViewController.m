//
//  ViewController.m
//  12-抽屉效果
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "XMGTableViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 让我的主要显示视图显示tableView
    
    XMGTableViewController *tableViewVc = [[XMGTableViewController alloc] init];
    tableViewVc.view.frame = self.mainV.bounds;
    
    [self.mainV addSubview:tableViewVc.view];
    
    [self addChildViewController:tableViewVc];
    
    // 设计原理:把A控制器的view添加到B控制器的view,那么A控制器必须成为B控制器的子控制器
    
}



@end
