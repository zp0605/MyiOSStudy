//
//  DragViewController.m
//  12-抽屉效果
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "DragViewController.h"

@interface DragViewController ()

@property (nonatomic, weak) UIView *leftV;
@property (nonatomic, weak) UIView *rightV;
@property (nonatomic, weak) UIView *mainV;

@end

@implementation DragViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加子控件
    [self setUpAllChildView];
    
    // 添加手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    
    [_mainV addGestureRecognizer:pan];
}

// 只要手指在mainV拖动的时候调用
- (void)pan:(UIPanGestureRecognizer *)pan
{
    // 让mainV随着手指移动而移动
    
    // 获取x轴偏移量
    CGFloat offsetX = [pan translationInView:_mainV].x;
    
    // 修改mainV的frame
    _mainV.frame = [self frameWithOffsetX:offsetX];
    
    // 复位
    [pan setTranslation:CGPointZero inView:_mainV];
    
    // 判断下当前显示左边的view,还是右边的view
    [self isShowLeftView];
}

// 判断下当前显示左边的view,还是右边的view
- (void)isShowLeftView
{
    if (_mainV.frame.origin.x > 0) { // 往右边,显示左边
        _rightV.hidden = YES;
    }else if (_mainV.frame.origin.x < 0){ // 往左边,显示右边
        _rightV.hidden = NO;
    }
}

// 计算当前mainV最新的frame
- (CGRect)frameWithOffsetX:(CGFloat)offsetX
{
    CGRect frame = _mainV.frame;
    
    frame.origin.x += offsetX;
    
    return frame;
}

// 添加子控件
- (void)setUpAllChildView
{
    // left
    UIView *leftV = [[UIView alloc] initWithFrame:self.view.bounds];
    _leftV = leftV;
    leftV.backgroundColor = [UIColor greenColor];
    [self.view addSubview:leftV];
    
    // right
    UIView *rightV = [[UIView alloc] initWithFrame:self.view.bounds];
    _rightV = rightV;
    rightV.backgroundColor = [UIColor blueColor];
    [self.view addSubview:rightV];
    
    // main
    UIView *mainV = [[UIView alloc] initWithFrame:self.view.bounds];
    _mainV = mainV;
    mainV.backgroundColor = [UIColor redColor];
    [self.view addSubview:mainV];
}

@end
