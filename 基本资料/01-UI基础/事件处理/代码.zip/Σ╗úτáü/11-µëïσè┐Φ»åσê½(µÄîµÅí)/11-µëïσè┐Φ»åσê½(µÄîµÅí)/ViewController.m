//
//  ViewController.m
//  11-手势识别(掌握)
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController
#pragma mark - UIGestureRecognizerDelegate
// 是否允许接收手指
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
//{
//    // 让控件左边点击,右边不点击
//    CGPoint curP = [touch locationInView:_imageView];
//    if (curP.x < _imageView.bounds.size.width * 0.5) { // 左边
//        return YES;
//    }else{
//        
//        return NO;
//    }
//}


// Simultaneously:同时
// 每次触发多个手势的时候都会询问下代理是否支持多个手势
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    // 表示同时支持多个手势
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    [self setUpPinch];
    
    [self setUpRotation];
    
    // 如何让一个手势同时支持缩放和旋转,必须通过代理
    
    
}
// 捏合手势
- (void)setUpPinch
{
    // 缩放
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinch:)];
    
    pinch.delegate = self;
    
    [_imageView addGestureRecognizer:pinch];
}

- (void)pinch:(UIPinchGestureRecognizer *)pinch
{
    _imageView.transform = CGAffineTransformScale(_imageView.transform, pinch.scale, pinch.scale);
    
    // 复位
    pinch.scale = 1;
    
}

// 添加旋转手势
- (void)setUpRotation
{
    // 旋转
    UIRotationGestureRecognizer *rotation = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotation:)];
    rotation.delegate = self;
    
    [_imageView addGestureRecognizer:rotation];

}
- (void)rotation:(UIRotationGestureRecognizer *)rotation
{
    _imageView.transform = CGAffineTransformRotate(_imageView.transform, rotation.rotation);
    
    // 复位
    rotation.rotation = 0;
}

// 添加一个拖动手势
- (void)setUpPan
{
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    
    [_imageView addGestureRecognizer:pan];

}


- (void)pan:(UIPanGestureRecognizer *)pan
{
    // 获取手指的偏移量
    CGPoint transP = [pan translationInView:_imageView];
    
    // 修改控件形变
    _imageView.transform = CGAffineTransformTranslate(_imageView.transform, transP.x, transP.y);
    
    // 复位,相对于上一次
    [pan setTranslation:CGPointZero inView:_imageView];
    
    
    
    NSLog(@"%@",NSStringFromCGPoint(transP));
    
    NSLog(@"%s",__func__);
}

// 轻扫
- (void)setUpSwipe
{
    
    // 默认一个手势只能支持一个方向
    
    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe)];
    
    // 轻扫是有方向,默认往右边
    swipe.direction = UISwipeGestureRecognizerDirectionLeft;
    
    [_imageView addGestureRecognizer:swipe];
    
    
    // 往上
    UISwipeGestureRecognizer *swipeUp = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe)];
    
    // 轻扫是有方向,默认往右边
    swipeUp.direction = UISwipeGestureRecognizerDirectionUp;
    
    [_imageView addGestureRecognizer:swipeUp];
    
    // 控件能支持很多手势,但是一定不要照成手势冲突
}

- (void)swipe
{
    NSLog(@"%s",__func__);
}

// 添加长按手势
- (void)setUplongPress
{
    // 长按
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    
    [_imageView addGestureRecognizer:longPress];

}

- (void)longPress:(UILongPressGestureRecognizer *)longPress
{
    // 在一开始长按的时候做事情
    if (longPress.state == UIGestureRecognizerStateBegan) {
        
        NSLog(@"%s",__func__);
    }
    
}

// 添加点按手势
- (void)setUpTap
{
    // 点按
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    tap.delegate = self;
    
    [_imageView addGestureRecognizer:tap];
}

- (void)tap
{
    NSLog(@"%s",__func__);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
