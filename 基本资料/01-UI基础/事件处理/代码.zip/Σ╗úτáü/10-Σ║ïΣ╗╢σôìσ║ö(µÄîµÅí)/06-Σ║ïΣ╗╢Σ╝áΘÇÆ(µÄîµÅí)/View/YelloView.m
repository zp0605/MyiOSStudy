//
//  YelloView.m
//  06-事件传递(掌握)
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "YelloView.h"

@implementation YelloView

//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    NSLog(@"%s",__func__);
//    
//    // 系统底层事件响应:把事件传递给上一个响应者,交给上一个响应者处理事件.
//    // 谁是黄色view的上一个响应者,蓝色
//    // 上一个响应者是父控件
//    // super-> 父类 不是父控件superview
//    [super touchesBegan:touches withEvent:event];
//}

@end
