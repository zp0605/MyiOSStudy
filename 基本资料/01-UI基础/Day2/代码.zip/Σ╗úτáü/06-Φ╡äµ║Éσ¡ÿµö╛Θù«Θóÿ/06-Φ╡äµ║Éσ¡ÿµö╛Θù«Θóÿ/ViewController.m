//
//  ViewController.m
//  06-资源存放问题
//
//  Created by xiaomage on 15/12/26.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"

/**
   加载图片的方式:
   1. imageNamed:
   2. imageWithContentsOfFile:
 
   1. 加载Assets.xcassets这里面的图片:
    1> 打包后变成Assets.car
    2> 拿不到路径
    3> 只能通过imageNamed:来加载图片
    4> 不能通过imageWithContentsOfFile:来加载图片
 
   2. 放到项目中的图片:
    1> 可以拿到路径
    2> 能通过imageNamed:来加载图片
    3> 也能通过imageWithContentsOfFile:来加载图片
 
 */

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // 图片的设置方式
    
    // 方式一
//    self.imageView.image = [UIImage imageNamed:@"1"];
    
    // 方式二
    // 路径
    NSString *path = [[NSBundle mainBundle] pathForResource:@"1" ofType:@"png"];
    self.imageView.image = [UIImage imageWithContentsOfFile:path];
}

@end
