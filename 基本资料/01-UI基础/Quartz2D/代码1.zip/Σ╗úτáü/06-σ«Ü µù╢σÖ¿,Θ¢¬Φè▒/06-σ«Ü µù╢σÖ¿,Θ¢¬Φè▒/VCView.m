//
//  VCView.m
//  06-定 时器,雪花
//
//  Created by Gavin on 15/9/13.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "VCView.h"

@implementation VCView


-(void)awakeFromNib{

    //添加一个定时器
//    [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(update) userInfo:nil repeats:YES];
    
    //0.01. 0.01
    //0.02. 0.02
    
    //创建CADisplayLink (当每一屏幕刷新就会调用 每一秒刷新60)
    CADisplayLink *link = [CADisplayLink displayLinkWithTarget:self selector:@selector(update)];
    [link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    
    
}

- (void)update{

    NSLog(@"adaf");
    _snowY += 10;
    
    if (_snowY >self.bounds.size.height) {
        _snowY = 0;
    }
    //setNeedsDisplay它会调用drawRect,它并不是立马,只是设了一个标志,当下一次屏幕刷新的调用.
    [self setNeedsDisplay];
    
}

static int _snowY = 0;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code

    //1.加载图片
    UIImage *image =  [UIImage imageNamed:@"雪花"];
    [image drawAtPoint:CGPointMake(0, _snowY)];
    
    
}


@end
