//
//  ProgressView.m
//  02-下载进度条(重绘)
//
//  Created by xiaomage on 15/9/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ProgressView.h"

@implementation ProgressView

-(void)setProgress:(CGFloat)progress{
    _progress = progress;
    
    //如果我们手动调用drawRect,系统是不会给我们生成跟View相关联的上下文.
    //系统调用drawRect的时候,才会生成跟View相关联上下文.
    [self drawRect:self.bounds];
    
    //setNeedsDisplay底层就会调用drawRect.系统自动调用 .
    [self setNeedsDisplay];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    //画弧
    CGPoint center = CGPointMake(rect.size.width * 0.5 , rect.size.height * 0.5 );
    CGFloat radius = rect.size.width * 0.5 - 10;
    CGFloat startA = -M_PI_2;
    CGFloat endA = -M_PI_2 + self.progress * M_PI * 2;
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:startA endAngle:endA clockwise:YES];
    
    [path stroke];
    

    
}


@end
