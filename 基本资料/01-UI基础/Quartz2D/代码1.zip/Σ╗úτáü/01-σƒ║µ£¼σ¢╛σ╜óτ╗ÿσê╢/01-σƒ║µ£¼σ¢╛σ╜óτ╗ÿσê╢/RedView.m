//
//  RedView.m
//  01-基本图形绘制
//
//  Created by xiaomage on 15/9/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "RedView.h"

@implementation RedView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.


-(void)awakeFromNib{

  
    
}



//作用:专门用绘图
//什么时候调用:在View显示的时候调用
//rect:当前View的bounds
- (void)drawRect:(CGRect)rect {
    
    //无论有没有看到上下文.只要在View上面绘图,就必须在drawRect方法.
  
    //cornerRadius:圆角半径
//    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(50, 50, 100, 100) cornerRadius:50];
    
    //画椭圆
//    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(50, 50, 100, 100)];
    
    //ArcCenter:圆心
    //radius:圆的半径
    //startAngle:开始角度//起始点圆的最右侧.
    //endAngle:截至角度
    //clockwise:顺时针还是逆时针 YES:顺时针 NO:逆时针
    
    CGPoint center = CGPointMake(rect.size.width * 0.5, rect.size.height * 0.5);
    CGFloat radius = rect.size.width * 0.5 - 10;
    CGFloat startA = 0;
    CGFloat endA = -M_PI_2;
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:startA endAngle:endA clockwise:NO];
    
    [path addLineToPoint:center];
    
    //封闭路径
//    [path closePath];
    
    [[UIColor blueColor] set];
    
    //fill,会自动把路径给关闭
    [path fill];

}

//画矩形.
- (void)drawrect{

    //画矩形.
    //1.获取上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //2.描述路径
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(50, 50, 100, 100)];
    //3.把路径添加到上下文
    CGContextAddPath(ctx, path.CGPath);
    
    [[UIColor yellowColor] set];
    
    //4.把上下文的内容显示
    CGContextFillPath(ctx);
    
}


//添加曲线
- (void)drawQuadCurve{

    
    //1.获取跟View相关联的上下文
    CGContextRef ctx =  UIGraphicsGetCurrentContext();
    //2.描述路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    //2.1设置起点
    [path moveToPoint:CGPointMake(20, 200)];
    //2.2添加一条曲线到某个点.
    [path addQuadCurveToPoint:CGPointMake(200, 200) controlPoint:CGPointMake(100, 10)];
    
    CGContextSetLineWidth(ctx, 10);
    
    //3.把路径添加到上下文
    CGContextAddPath(ctx, path.CGPath);
    //4.把上下文的内容显示出来.
    CGContextStrokePath(ctx);
}

//画直线
- (void)drawLine{

    // Drawing code
    NSLog(@"%s",__func__);
    NSLog(@"%@",NSStringFromCGRect(self.bounds));
    
    //1.取得一个跟View相关联的上下文.
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //2.描述路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    //2.1.设置起点
    [path moveToPoint:CGPointMake(10, 100)];
    //2.1.添加一根线到某个点
    [path addLineToPoint:CGPointMake(200, 20)];
    
    //一个路径上面可以画多条线
    //    [path moveToPoint:CGPointMake(10, 150)];
    //    [path addLineToPoint:CGPointMake(200, 100)];
    
    //把上一条线的终点当作是下一条线的起点.
    [path addLineToPoint:CGPointMake(150, 200)];
    
    
    //设置上下文的状态
    //设置线的宽度
    CGContextSetLineWidth(ctx, 10);
    //设置线的连接样式
    CGContextSetLineJoin(ctx, kCGLineJoinBevel);
    //设置顶角的样式
    CGContextSetLineCap(ctx, kCGLineCapRound);
    //设置线的颜色
    [[UIColor greenColor] setStroke];
    
    
    //3.把路径添加到上下文
    CGContextAddPath(ctx, path.CGPath);
    //4.把上下文的内容显示View fill stroke
    CGContextStrokePath(ctx);
    

}


@end
