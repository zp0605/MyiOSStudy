//
//  ViewController.m
//  09-给图片加水印
//
//  Created by Gavin on 15/9/13.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIImage *image = [UIImage imageNamed:@"卡哇伊"];
    
    //生成图片.
    //size:开开启一个多大图片上下文.
    //opaque:不透度
    //scale:0
    //开启跟图片相同的大小上下文.
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0.0);
    //把图片给绘制图片上下文.
    [image drawAtPoint:CGPointZero];
    //绘制文字
    NSString *str = @"小码哥";
    [str drawAtPoint:CGPointZero withAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:20]}];
    //生成图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    //手动关闭上下文
    UIGraphicsEndImageContext();

    self.imageV.image = newImage;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
