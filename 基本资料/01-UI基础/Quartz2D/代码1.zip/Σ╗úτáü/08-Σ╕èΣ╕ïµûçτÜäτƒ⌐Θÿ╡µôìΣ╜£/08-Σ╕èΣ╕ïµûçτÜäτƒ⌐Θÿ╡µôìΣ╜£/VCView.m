//
//  VCView.m
//  08-上下文的矩阵操作
//
//  Created by Gavin on 15/9/13.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "VCView.h"

@implementation VCView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {

    
    //1.获得跟View相关联的上下文
    CGContextRef ctx =  UIGraphicsGetCurrentContext();
    //2.描述路径
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(-100, -50, 200, 100)];
    [[UIColor redColor] set];
    
    //上下文的矩阵操作,必须得要在添加路径之前做操作.
    //平移
    CGContextTranslateCTM(ctx, 100, 50);
    
    //缩放
    CGContextScaleCTM(ctx, 0.5, 0.5);
    
    //旋转
    CGContextRotateCTM(ctx, M_PI_4);
    
    //3.把路径 添加到当前上下文
    CGContextAddPath(ctx, path.CGPath);
    

    //4.把上下文的内容渲染出来.
    CGContextFillPath(ctx);
    
    
    
    
    
    
    
}


@end
