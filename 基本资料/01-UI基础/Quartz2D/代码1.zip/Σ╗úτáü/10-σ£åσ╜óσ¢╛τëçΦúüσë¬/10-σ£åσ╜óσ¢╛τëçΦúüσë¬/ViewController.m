//
//  ViewController.m
//  10-圆形图片裁剪
//
//  Created by Gavin on 15/9/13.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //1.加载图片
    UIImage *image = [UIImage imageNamed:@"阿狸头像"];
    //2.生成一个跟图片相同大小图片上下文
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
    //3.在上下文添加一个圆形裁剪区域
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    
    //把路径设置成裁剪区域
    [path addClip];

    //4.把图片绘制图片上下文.
    [image drawAtPoint:CGPointZero];
    
    //5.生成一张图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    //6.关闭图片上下文.
    UIGraphicsEndImageContext();
    
    self.imageV.image = newImage;
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
