//
//  ViewController.m
//  01-带有边框的图片裁剪
//
//  Created by Gavin on 15/9/14.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+image.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    //1.加载
    UIImage *image = [UIImage imageNamed:@"阿狸头像"];
    //2.边框宽度
    CGFloat borderW = 10;
    //3.开启图片上下文.
    CGSize size = CGSizeMake(image.size.width + 2 * borderW, image.size.height + 2 * borderW);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    //4.先描述一个大圆,设为填充
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, size.width, size.height)];
    [[UIColor redColor] set];
    [path fill];
    //5.再添加一个小圆,把小圆设裁剪区域
    
    path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(borderW, borderW, image.size.width, image.size.height)];
    [path addClip];
    
    //6.把图片给绘制上下文.
    [image drawInRect:CGRectMake(borderW, borderW, image.size.width, image.size.height)];
    //7.生成一张新的图片
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    //8.关闭上下文.
    UIGraphicsEndImageContext();
    
    
    
    
//  抽取出来的功能
    self.imageV.image = [UIImage imageWithBorderWidth:10 borderColor:[UIColor greenColor] image:[UIImage imageNamed:@"阿狸头像"]];

}



- (UIImage *)imageWithBorderWidth:(CGFloat)borderW borderColor:(UIColor *)color image:(UIImage *)image{

    //3.开启图片上下文.
    CGSize size = CGSizeMake(image.size.width + 2 * borderW, image.size.height + 2 * borderW);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    //4.先描述一个大圆,设为填充
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, size.width, size.height)];
    //设置边框的颜色
    [color set];
    [path fill];
    //5.再添加一个小圆,把小圆设裁剪区域
    
    path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(borderW, borderW, image.size.width, image.size.height)];
    [path addClip];
    
    //6.把图片给绘制上下文.
    [image drawInRect:CGRectMake(borderW, borderW, image.size.width, image.size.height)];
    //7.生成一张新的图片
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    //8.关闭上下文.
    UIGraphicsEndImageContext();
    
    return newImage;
    
}











- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
