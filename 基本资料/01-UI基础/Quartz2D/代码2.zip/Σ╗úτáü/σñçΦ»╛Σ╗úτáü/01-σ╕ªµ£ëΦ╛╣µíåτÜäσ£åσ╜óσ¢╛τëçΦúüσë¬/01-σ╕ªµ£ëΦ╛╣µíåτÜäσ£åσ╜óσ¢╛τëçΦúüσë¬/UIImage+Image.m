//
//  UIImage+Image.m
//  01-带有边框的圆形图片裁剪
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "UIImage+Image.h"

@implementation UIImage (Image)



+ (UIImage *)imageWithBorderWidth:(CGFloat)borderW borderColor:(UIColor *)color image:(UIImage *)image{
    
    
    //2.开启一个比原始图片宽高多2倍边框宽度的图片上下文.
    CGSize size = CGSizeMake(image.size.width + 2 * borderW, image.size.height + 2 * borderW);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    //3.绘制一个和图片上下文宽高相同的圆形填充区域
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, size.width, size.height)];
    [color set];
    [path fill];
    //4.添加一个圆形的裁剪区域.x,y,分别是边框的宽度,宽高分别的图片的宽高.
    path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(borderW, borderW, image.size.width, image.size.height)];
    [path addClip];
    //5.把图片绘制到图片上下文.位置和裁剪区域的位置一样.
    [image drawInRect:CGRectMake(borderW, borderW, image.size.width, image.size.height)];
    //6.从图片上下文当中生成一张图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    //7.关闭图片上下文
    UIGraphicsEndImageContext();
    
    return  newImage;
    
    
}


@end
