//
//  ClockView.m
//  05-手势解锁
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ClockView.h"


@interface ClockView()

@property(nonatomic,strong) NSMutableArray *selectBtn;

@property(nonatomic,assign) CGPoint curP;

@end


@implementation ClockView


-(NSMutableArray *)selectBtn{
    
    if (_selectBtn == nil) {
        _selectBtn = [NSMutableArray array];
    }
    return _selectBtn;
}



-(void)awakeFromNib{
    
    //初始化
    [self setUp];
}


-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
    //初始化
        [self setUp];
    }
    return self;
}

- (void)setUp{
    
    //添加按钮
    for(int i = 0; i < 9; i++){
    
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = i;
        btn.userInteractionEnabled = NO;
        [btn setImage:[UIImage imageNamed:@"gesture_node_normal"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"gesture_node_highlighted"] forState:UIControlStateSelected];
        [self addSubview:btn];
        
    }
    

}

//取出当前手指所在的点
- (CGPoint)getCurrentPoint:(NSSet *)touches{
    
    //取出当前手指所在的点
    UITouch *touch = [touches anyObject];
    return  [touch locationInView:self];
}



//判断当前手指在不在按钮上

- (UIButton *)btnRectContainsPoint:(CGPoint)point{
    
    //判断当前手指所在的点在不在按钮上.
    for (UIButton *btn in self.subviews) {
        //如果在按钮.让按钮成为选中状态
        if (CGRectContainsPoint(btn.frame, point)) {
            return btn;
        }
    }
    return nil;
    
}




-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    //取出当前手指所在的点
    CGPoint curP = [self getCurrentPoint:touches];
    //判断当前手指所在的点在不在按钮上
    UIButton *btn = [self btnRectContainsPoint:curP];
    
    if (btn && btn.selected == NO) {
        btn.selected = YES;
        [self.selectBtn addObject:btn];
    }
    
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    //取出当前手指所在的点
    CGPoint curP = [self getCurrentPoint:touches];
    //判断当前手指所在的点在不在按钮上
    UIButton *btn = [self btnRectContainsPoint:curP];
    
    if (btn && btn.selected == NO) {
        btn.selected = YES;
        [self.selectBtn addObject:btn];
      
    }
    self.curP = curP;
    [self setNeedsDisplay];
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{

    
    NSMutableString *str = [NSMutableString string];
    
    for (UIButton *btn in self.selectBtn) {
        btn.selected = NO;
        [str appendFormat:@"%d",(int)btn.tag];
    }
    
    NSLog(@"%@",str);
    
    [self.selectBtn removeAllObjects];
    [self setNeedsDisplay];
    
    
}


-(void)layoutSubviews{

    [super layoutSubviews];
    
    int cloumn = 3;
    CGFloat btnWH = 74;
    CGFloat margin = (self.bounds.size.width - cloumn * btnWH) / (cloumn + 1);
    
    CGFloat x = 0;
    CGFloat y = 0;
    
    int curCloumn = 0;
    int curRow = 0;
    
    
    for (int i = 0; i < self.subviews.count; i++) {
        UIButton *btn = self.subviews[i];
        
        curCloumn = i % cloumn;
        curRow = i / cloumn;
        
        x = margin + curCloumn * (btnWH + margin);
        y = curRow * (btnWH + margin);

        btn.frame = CGRectMake(x, y, btnWH, btnWH);
    }
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    
    
    if (self.selectBtn.count) {
        
        UIBezierPath *path = [UIBezierPath bezierPath];
        for(int i = 0; i < self.selectBtn.count; i++){

            UIButton *btn = self.selectBtn[i];
            if (i == 0) {
                [path moveToPoint:btn.center];
            }else{
                [path addLineToPoint:btn.center];
            }
        }
        
        
        [path addLineToPoint:self.curP];
        
        
        [[UIColor redColor] set];
        [path setLineWidth:10];
        [path setLineJoinStyle:kCGLineJoinRound];
        [path stroke];
        
    }
    
  
    
    
}













@end
