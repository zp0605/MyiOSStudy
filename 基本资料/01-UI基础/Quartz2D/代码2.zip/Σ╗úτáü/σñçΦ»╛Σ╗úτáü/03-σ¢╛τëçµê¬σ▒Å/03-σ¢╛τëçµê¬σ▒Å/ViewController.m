//
//  ViewController.m
//  03-图片截屏
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property(nonatomic,assign)CGPoint startP;

@property(nonatomic,weak)UIView *coverView;
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController


-(UIView *)coverView{
    if (_coverView == nil) {
        
        UIView *view = [[UIView alloc] init];
        view.backgroundColor = [UIColor blackColor];
        view.alpha = 0.7;
        _coverView = view;
        [self.view addSubview:view];
      
    }
    return _coverView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    
    
}

- (IBAction)pan:(UIPanGestureRecognizer *)pan{
    
    //获取手指当前的点.
    CGPoint curP = [pan locationInView:self.view];
    if (pan.state == UIGestureRecognizerStateBegan) {
        
        self.startP = curP;
        
    }else if(pan.state == UIGestureRecognizerStateChanged){
        
        CGFloat offsetX = curP.x - self.startP.x;
        CGFloat offsetY = curP.y - self.startP.y;
        CGRect rect = CGRectMake(self.startP.x, self.startP.y, offsetX, offsetY);
        
        //添加UIView
        self.coverView.frame = rect;
    }else if(pan.state == UIGestureRecognizerStateEnded){
        
        UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 0);
        //把当前的选中范围设置成裁剪区域.
        UIBezierPath *path = [UIBezierPath  bezierPathWithRect:self.coverView.frame];
        [path addClip];
        
        //获取当前的上下文
        CGContextRef ctx = UIGraphicsGetCurrentContext();
        //把当前UIImageView上的图片渲染到图片上下文上面.
        [self.imageV.layer renderInContext:ctx];
        //从图片上下文当中生成一张新的图片
        UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
        //从新给UIImageView赋值;
        self.imageV.image = newImage;
        //关闭图片上下文.
        UIGraphicsEndImageContext();
        
        [self.coverView removeFromSuperview];
        
    }
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
