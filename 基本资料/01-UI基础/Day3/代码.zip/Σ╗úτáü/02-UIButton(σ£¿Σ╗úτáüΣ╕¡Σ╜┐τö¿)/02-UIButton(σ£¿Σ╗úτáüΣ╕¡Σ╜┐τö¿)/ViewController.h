//
//  ViewController.h
//  02-UIButton(在代码中使用)
//
//  Created by xiaomage on 15/12/28.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

